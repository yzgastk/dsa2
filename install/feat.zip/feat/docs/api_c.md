# Feat C++ API

This is the C++ API for [Feat](http://github.com/lacava/feat). 

[Back to main documentation](http://lacava.github.io/feat)

## Quick links

 - [Feat](https://lacava.github.io/feat/cpp_api/db/dff/classFT_1_1Feat.html)
 - [Parameters](https://lacava.github.io/feat/cpp_api/de/d2c/structFT_1_1Parameters.html)
 - [Evaluation](https://lacava.github.io/feat/cpp_api/de/dcf/namespaceFT_1_1Eval.html)
 - [Selection](https://lacava.github.io/feat/cpp_api/d0/df4/namespaceFT_1_1Sel.html)
 - [Variation](https://lacava.github.io/feat/cpp_api/d5/d5e/namespaceFT_1_1Vary.html)
 - [Population](https://lacava.github.io/feat/cpp_api/d0/dd8/namespaceFT_1_1Pop.html)
